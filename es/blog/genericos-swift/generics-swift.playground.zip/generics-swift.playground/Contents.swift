import UIKit

func logString(value: String) {
    print("INFO - Value recorded: \(value)")
}

logString(value: "RandomResult")


func logInt(value: Int) {
    print("INFO - Value recorded: \(value)")
}

logInt(value: 10)

func log<T>(value: T) {
    print("INFO - Value recorded: \(value)")
}

log(value: "A message")
log(value: 10)
log(value: false)

struct StringsStore {
    var content: [String]
    
    mutating func add(string: String) {
        content.append(string)
    }
    
    mutating func clear() {
        content.removeAll()
    }
}

struct ValuesStore<Element> {
    var content: [Element]
    
    mutating func add(value: Element) {
        content.append(value)
    }
    
    mutating func clear() {
        content.removeAll()
    }
}

var intsStore = ValuesStore(content: [2,4,5])
intsStore.add(value: 10)
print(intsStore.content)
var doublesStore = ValuesStore(content: [2.5, 4.7, 5.8])
doublesStore.add(value: 4.7)
print(doublesStore.content)

extension ValuesStore {
    var lastElement: Element? {
        content.last
    }
}

print(intsStore.lastElement ?? "Empty Store")

func sumTwoValues<T>(valueA: T, valueB: T) -> T where T: Numeric {
    valueA + valueB
}

sumTwoValues(valueA: 2, valueB: 5)
sumTwoValues(valueA: 10.5, valueB: 20.6)

func displayTemp<City,Temp>(city: City, temp: Temp) where City: StringProtocol, Temp: Numeric {
    print("\(city):\(temp)")
}

displayTemp(city: "Valencia", temp: 20)
displayTemp(city: "Munich", temp: 5.5)

func displayT(city: String, temp: any Numeric) {
    print("\(city):\(temp)")
}

displayT(city: "Torrent", temp: 24)
