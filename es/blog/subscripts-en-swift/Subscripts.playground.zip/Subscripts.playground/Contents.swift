struct Fibonacci {
    subscript(position: Int) -> Int {
        guard position > 1 else { return position }
        var a = 0, b = 1
        for _ in 2...position {
            let temp = a + b
            a = b
            b = temp
        }
        return b
    }
}

let fib = Fibonacci()
// Prints "13"
print(fib[7])

struct Cube3D {
    private var cells: [[[Int]]]
    let size: Int
    
    init(size: Int, defaultValue: Int = 0) {
        self.size = size
        self.cells = Array(repeating: Array(repeating: Array(repeating: defaultValue,
                                                             count: size),
                                            count: size),
                           count: size)
    }
    
    subscript(x: Int, y: Int, z: Int) -> Int {
        get {
            guard isValidIndex(x: x, y: y, z: z) else {
                fatalError("Index out of range")
            }
            return cells[x][y][z]
        }
        set {
            guard isValidIndex(x: x, y: y, z: z) else {
                fatalError("Index out of range")
            }
            cells[x][y][z] = newValue
        }
    }
    
    subscript(xRange: Range<Int>, yRange: Range<Int>, z: Int) -> [[Int]] {
        guard isValidRange(xRange: xRange,
                           yRange: yRange,
                           z: z) else {
            fatalError("Range out of cube bounds")
        }
        return xRange.map { x in
            yRange.map { y in
                cells[x][y][z]
            }
        }
    }
    
    private func isValidIndex(x: Int, y: Int, z: Int) -> Bool {
        x >= 0 && x < size && y >= 0 && y < size && z >= 0 && z < size
    }
    
    private func isValidRange(xRange: Range<Int>, yRange: Range<Int>, z: Int) -> Bool {
        xRange.lowerBound >= 0 && xRange.upperBound <= size &&
               yRange.lowerBound >= 0 && yRange.upperBound <= size &&
               z >= 0 && z < size
    }
}

var cube = Cube3D(size: 5, defaultValue: 0)

cube[0, 0, 0] = 1
cube[1, 2, 3] = 5
cube[4, 4, 4] = 9

// Prints  "1"
print(cube[0, 0, 0])
// Prints "5"
print(cube[1, 2, 3])
// Prints "9"
print(cube[4, 4, 4])

let slice = cube[0..<2, 0..<3, 0]
// Prints [[1, 0, 0], [0, 0, 0]]
print(slice)

enum DayOfWeek: Int {
    case monday = 1
    case tuesday
    case wednesday
    case thursday
    case friday
    case saturday
    case sunday
    
    static subscript(index: Int) -> DayOfWeek? {
        return DayOfWeek(rawValue: index)
    }
}

// day is equal to .wednesday
let day = DayOfWeek[3]



