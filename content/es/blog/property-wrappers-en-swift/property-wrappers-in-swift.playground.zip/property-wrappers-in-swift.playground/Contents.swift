import Foundation

@propertyWrapper
struct DashCase {
    private var text = ""
    var wrappedValue: String {
        get {
            text
        }
        set {
            text = newValue.lowercased().replacingOccurrences(of: " ", with: "-")
        }
    }
}

struct Branch {
    @DashCase var name: String
}

var branch = Branch()
branch.name = "A Random Branch Name"

print(branch.name)

struct File {
    @DashCase var name: String
}

var file = File()
file.name = "A Random File Name"

print(file.name)

@propertyWrapper
struct SnakeCase {
    var wrappedValue: String
    
    init(wrappedValue: String) {
        self.wrappedValue = wrappedValue.replacingOccurrences(of: " ", with: "_").lowercased()
    }
}


struct Table {
    @SnakeCase var name: String
}

var table = Table(name: "hello World")
print(table.name)


@propertyWrapper
struct Capitalized {
    private var text: String
    private(set) var projectedValue = false
    var wrappedValue: String {
        get {
            text
        }
        set {
            text = newValue.capitalized
        }
    }
    
    init(wrappedValue: String) {
        self.text = wrappedValue.capitalized
        projectedValue = true
    }
}

struct CustomText {
    @Capitalized var title: String
}

let text = CustomText(title: "One more thing...")
print(text.title)
print(text.$title)

