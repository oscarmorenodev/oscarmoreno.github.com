import SwiftUI

struct Driver {
    var name: String
}

let alo = Driver(name: "Fernando Alonso")
let pathToNameProperty = \Driver.name

let driverName = alo[keyPath: pathToNameProperty]
print(driverName) // Prints "Fernando Alonso"

struct Race {
    var winner: Driver
    
    func displayWinnerProperty(keypath: KeyPath<Driver, String>) {
        print("The winner is \(winner[keyPath: keypath])")
    }
}

let sai = Driver(name: "Carlos Sainz")
let race = Race(winner: sai)
race.displayWinnerProperty(keypath: \.name) // Prints "The winner is Carlos Sainz"

var verstappenPoints = (a: 25, b: 18, c:25)
// Equivalent to verstappenPoints = (a: 18, b: 25, c: 25)
verstappenPoints[keyPath: \.self] = (a: 18, b: 25, c: 25)
print(verstappenPoints) // Prints "(a: 18, b: 25, c: 25)"


List {
    ForEach([2, 4, 6, 8, 10], id: \.self) {
        Text("\($0) is even")
    }
}

struct Championsip {
    var winner: Driver
    
    init(winnerName: String) {
        self.winner = Driver(name: winnerName)
    }
}

let champion = Championsip(winnerName: "Max Verstappen")
let nestedKeyPath = \Championsip.winner.name

let championName = champion[keyPath: nestedKeyPath]
print(championName)  // Prints "Max Verstappen"

let tracks = ["Montmelo", "Monza", "Spa", "Suzuka"]
let fasterTrack = tracks[keyPath: \[String].[1]]
print(fasterTrack) // Prints "Monza"

var index = 1
let pathToTrack = \[String].[index]
let closure: ([String]) -> String = { strings in strings[index] }

print(tracks[keyPath: pathToTrack]) // Prints "Monza"
print(closure(tracks)) // Prints "Monza"

index += 1
print(tracks[keyPath: pathToTrack]) // Prints "Monza"

// Because 'fn' closes over 'index', it uses the new value
print(closure(tracks)) // Prints "Spa"


let firstTrack: String? = tracks.first
let count = tracks[keyPath: \[String].first?.count]
print(count as Any) // Prints Montmelo characters number "Optional(8)"

struct Lap {
    var time: Double
    var valid: Bool
}
var timelaps = [
    Lap(time: 106.0, valid: true),
    Lap(time: 99.5, valid: true),
    Lap(time: 102.0, valid: false)
]

// Usual
let validLaps1 = timelaps.filter{ $0.valid }
print(validLaps1.count) // Prints "2"

// Equivalent with key-paths
let validLaps2 = timelaps.filter(\.valid)
print(validLaps2.count) // Prints "2"

func displayValidLap() -> Int {
    print("Valid lap!")
    return 0
}

let greetingKeyPath = \[Lap][displayValidLap()] // Prints "Valid lap!"

// Using greetingKeyPath doesn't call displayValidLap again.
let someLap = timelaps[keyPath: greetingKeyPath]
