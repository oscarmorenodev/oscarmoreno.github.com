import Foundation

struct User {
    let name: String
}

enum Resolution {
    case completed
    case dropped
}

enum State {
    case toDo(estimatedDate: Date)
    case inProgress(assignee: User)
    case done(minutes: Double)
    case close(Resolution)
}

let state = State.toDo(estimatedDate: Date.now.addingTimeInterval(86400))
let state2 = State.inProgress(assignee: .init(name: "John"))
let state3 = State.done(minutes: 10.0)
let state4 = State.close(.completed)

func manageTask(_ task: State) {
    switch task {
    case .toDo:
        print("Task is not started yet.")
    case .inProgress(let assignee):
        print("\(assignee) is working on it")
    case .done(var duration):
        duration /= 60
        print("Task was completed in \(duration) hours")
    case .close(let finalState):
        print("Task is finished. It was \(finalState)")
    }
}

manageTask(.toDo(estimatedDate: Date.now.addingTimeInterval(172.800)))

let user = User(name: "Erlich Bachman")
manageTask(.inProgress(assignee: user))

manageTask(.done(minutes: 90.0))

enum ArcadeMachineError: Error {
    case invalidSelection
    case insufficientFunds(coinsNeeded: Int)
    case userUnknown(user: String)
}

func displayError(_ error: ArcadeMachineError) {
    switch error {
    case .invalidSelection:
        print("Invalid selection")
    case .insufficientFunds(let coinsNeeded):
        print("Insufficient funds. You need \(coinsNeeded) coins")
    case .userUnknown(let user):
        print("User \(user) is unknown")
    }
}

displayError(.userUnknown(user: "pacman"))

enum UserAction {
    case login(username: String, password: String)
    case logout
    case updateProfile(name: String, age: Int)
}

func performAction(_ action: UserAction) {
    switch action {
    case .login(let username, let password):
        print("Logging in with \(username) and \(password)")
    case .logout:
        print("Logging out")
    case .updateProfile(let name, let age):
        print("Updating profile with name: \(name), age: \(age)")
    }
}

performAction(.updateProfile(name: "grogu", age: 50))

enum MediaType {
    case image(url: String, resolution: (width: Int, height: Int))
    case video(url: String, duration: TimeInterval)
    case audio(url: String, bitrate: Int)
}

func handleMedia(_ media: MediaType) {
    switch media {
    case .image(let url, let resolution):
        print("Image URL: \(url), Resolution: \(resolution.width)x\(resolution.height)")
    case .video(let url, let duration):
        print("Video URL: \(url), Duration: \(duration) seconds")
    case .audio(let url, let bitrate):
        print("Audio URL: \(url), Bitrate: \(bitrate) kbps")
    }
}

handleMedia(.video(url: "R.Astley-never_gonna_give_you_up.mp4",
                   duration: 213))

enum AppState {
    case onboarding(step: Int)
    case loggedIn(userID: String)
    case loggedOut
}

func handleAppState(_ state: AppState) {
    switch state {
    case .onboarding(let step):
        print("Onboarding step \(step)")
    case .loggedIn(let userID):
        print("User logged in with ID \(userID)")
    case .loggedOut:
        print("User logged out")
    }
}

handleAppState(.onboarding(step: 1))


enum Filter {
    case priceRange(min: Double, max: Double)
    case category(name: String)
    case availability(isInStock: Bool)
}

func applyFilter(_ filter: Filter) {
    switch filter {
    case .priceRange(let min, let max):
        print("Filter by price range: \(min) - \(max)")
    case .category(let name):
        print("Filter by category: \(name)")
    case .availability(let isInStock):
        print("Filter by availability: \(isInStock ? "In stock" : "Out of stock")")
    }
}

applyFilter(.priceRange(min: 10.0, max: 20.0))
